import EmotionForm from "./EmotionForm";

function App() {
  return (
    <div className="min-h-screen bg-white">
      <EmotionForm />
    </div>
  );
}

export default App;
